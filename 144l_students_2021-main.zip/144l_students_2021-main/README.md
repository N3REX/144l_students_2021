# 144l_students_2021

This repository includes data, code, and supplementary information to be used by students for EEMB144L during the fall quarter 2021 (@) UCSB.
