# 2021 Bacterial Abundance Data README: 

Please note several things in this data sheet. You will find two tabs, one called 'Metadata' and the other called 'Data'. Differences between the Data sheet here and the 2018 sheet you used for the tutorial are the following:

- some of the abundance timepoints are missing. this is due to sample labels falling off in LN2. be sure to note this in your markdown file, notebook, and final report. 
- you will see 3 types of abundance data: all_cells, LNA_cells (low nucleic acid) and HNA_cells (high nucleic acid). you may want to investigate trends present in all three 
